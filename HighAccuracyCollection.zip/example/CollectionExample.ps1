﻿.\HighAccuracyCollection.ps1 -SUT 'SUT' -NTPServer 'time.windows.com'

.\HighAccuracyCollection.ps1 -SUT '192.168.10.132' -NTPServer '192.168.10.5'