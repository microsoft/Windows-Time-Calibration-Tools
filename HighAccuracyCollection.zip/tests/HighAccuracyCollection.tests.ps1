﻿Param ( 
    [Parameter(mandatory=$true)]
    [string] $SUT,

    [Parameter(mandatory=$true)]
    [String] $NTPServer,

    [Parameter(mandatory=$true)]
    [string] $logLocation

)
# Verifying Configuration
Describe 'High Accuracy Time' {
    Context 'Need to NTP Server Access of SUT' {
        $SUT, $NTPServer | ForEach-Object {
            # Not a great/reliable way to test UDP port availability
            It "$_ accept NTP Requests" {
                $stripchart = w32tm /stripchart /computer:$_ /rdtsc /samples:5
                ($stripchart[4..($stripchart.length - 1)] -match 'error:').Count | Should BeLessThan 2
            }
        }
    }

    Context 'Reporting Tools' {
        It 'Log Location must exist' {
            (Test-Path $LogLocation) | Should be $true
        }

        It 'Should have Gnuplot bin on the Path' {
            $env:Path.Split(';') -contains "$env:ProgramFiles\gnuplot\bin" | Should be $true
        }
        
        'Create-TimeChart.ps1','Test-WTCTDepedencies.ps1','Show-Percentiles.ps1',
        'TimeSampleCorrelation.exe','MedianFilter.exe','gnuplot.exe' | ForEach-Object {
            It "Should find $_" {
                Get-Command $_ -ErrorAction SilentlyContinue | Should be $true
            }
        }
    }
}
