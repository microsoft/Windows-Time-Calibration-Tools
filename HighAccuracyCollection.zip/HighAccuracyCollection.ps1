﻿param ( 
    [string] $SUT ,
    [string] $NTPServer , 
    [int]    $samples = 900
)

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

If (!( $isAdmin )) {
    Write-Host "-- Restarting as Administrator" -ForegroundColor Cyan ; Start-Sleep -Seconds 1
    Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs 
    exit
}

$here   = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Split-Path -Leaf $MyInvocation.MyCommand.Path
$tests  = "$here\tests\$($config -replace '.ps1', '.tests.ps1')"
$LocalLog = "$here\timeLogs\$SUT"

$Splat = @{
    NTPServer = $NTPServer
    SUT = $SUT
}

If (-not(Test-Path $LocalLog)) {
    New-Item $LocalLog -ItemType Directory -Force | Out-Null
}

$Env:Path += ";$env:ProgramFiles\gnuplot\bin;$here\helpers"

function Gather-W32TimeData {
    param (
        [Parameter(Mandatory=$true)]
        [string] $SUT,

        [Parameter(Mandatory=$true)]
        [string] $LogLocation,

        [Parameter(Mandatory=$true)]
        [string] $NTPServer
    )

    $SUT_Script = [scriptblock]::Create(" & w32tm /stripchart /computer:$($SUT) /rdtsc /period:1 /samples:$($samples) | Out-File $($logLocation)\$($SUT).out" )
    $Ref_Script = [scriptblock]::Create(" & w32tm /stripchart /computer:$($NTPServer) /rdtsc /period:1 /samples:$($samples) | Out-File $($logLocation)\$($NTPServer).out" )

    $SUT_Job = start-job -Name 'SUT-Time-Test' -ScriptBlock $SUT_Script 
    $Ref_Job = start-job -Name 'Ref-Time-Test' -ScriptBlock $Ref_Script

    Write-Host "`n`nCollecting data..."

    Wait-Job -Name 'SUT-Time-Test','Ref-Time-Test'

    "`n`nData collected : $logLocation"

    Stop-Job   -Name 'SUT-Time-Test','Ref-Time-Test' 
    Remove-Job -Name 'SUT-Time-Test','Ref-Time-Test'
}

$PesterResults = Invoke-Pester -Script @{Path=$tests;Parameters=@{logLocation=$LocalLog; SUT=$Splat.SUT ; NTPServer = $Splat.NTPServer}} -PassThru

If ($PesterResults.FailedCount -gt 0) {
    Write-Host "`n`nSomething failed and needs to be fixed before moving on!" -ForegroundColor White -BackgroundColor DarkRed
    Break
}
Else {
    Write-Host "`n`nPrerequisites met: Ready to Gather Data" -ForegroundColor Green
}

Gather-W32TimeData @Splat -LogLocation $LocalLog

Set-Location -Path $LocalLog

Create-TimeChart.ps1 -Name $Splat.SUT -ReferenceClock $Splat.NTPServer